package dev.donut;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class Events implements Listener {
    private final DonutPlugin pl;
    public Events(DonutPlugin pl) { this.pl = pl; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        pl.data.get(p.getUniqueId());
        pl.boards.create(p);
        if (!p.hasPlayedBefore()) {
            Location sp = Commands.getSpawn(pl);
            if (sp != null) p.teleportAsync(sp);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { pl.boards.remove(e.getPlayer()); }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player v = e.getEntity();
        pl.data.get(v.getUniqueId()).deaths++;
        Player k = v.getKiller();
        if (k != null && !k.equals(v)) {
            DataManager.PD kd = pl.data.get(k.getUniqueId());
            kd.kills++;
            double reward = pl.getConfig().getDouble("kill-reward", 500);
            kd.money += reward;
            pl.msg(k, "&aYou killed &f" + v.getName() + " &aand earned &f$" + DataManager.fmt(reward));
        }
    }
}
