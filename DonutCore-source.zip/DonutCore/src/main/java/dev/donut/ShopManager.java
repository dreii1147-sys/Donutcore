package dev.donut;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class ShopManager implements Listener {
    record Item(Material mat, double buy, double sell) {}
    static class Cat { String name; Material icon; List<Item> items = new ArrayList<>(); }
    static class Holder implements InventoryHolder {
        final String cat; Inventory inv;
        Holder(String c) { cat = c; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final DonutPlugin pl;
    private final Map<String, Cat> cats = new LinkedHashMap<>();
    private final Map<Material, Double> sellPrices = new HashMap<>();

    public ShopManager(DonutPlugin pl) { this.pl = pl; load(); }

    public void load() {
        cats.clear(); sellPrices.clear();
        ConfigurationSection s = pl.getConfig().getConfigurationSection("shop");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            ConfigurationSection sec = s.getConfigurationSection(key);
            if (sec == null) continue;
            Cat c = new Cat();
            c.name = key;
            Material icon = Material.matchMaterial(sec.getString("icon", "CHEST"));
            c.icon = icon == null ? Material.CHEST : icon;
            ConfigurationSection items = sec.getConfigurationSection("items");
            if (items != null) for (String m : items.getKeys(false)) {
                Material mat = Material.matchMaterial(m);
                if (mat == null) continue;
                double buy = items.getDouble(m + ".buy"), sell = items.getDouble(m + ".sell");
                c.items.add(new Item(mat, buy, sell));
                sellPrices.merge(mat, sell, Math::max);
            }
            cats.put(key, c);
        }
    }

    public void openMain(Player p) {
        Holder h = new Holder(null);
        Inventory inv = Bukkit.createInventory(h, 27, DonutPlugin.color("&d&lShop"));
        h.inv = inv;
        int slot = 10;
        for (Cat c : cats.values()) {
            if (slot > 16) break;
            ItemStack is = new ItemStack(c.icon);
            ItemMeta m = is.getItemMeta();
            m.setDisplayName(DonutPlugin.color("&d&l" + c.name));
            m.setLore(List.of(DonutPlugin.color("&7Click to browse"), DonutPlugin.color("&8" + c.items.size() + " items")));
            is.setItemMeta(m);
            inv.setItem(slot++, is);
        }
        p.openInventory(inv);
    }

    public void openCat(Player p, String name) {
        Cat c = cats.get(name);
        if (c == null) return;
        Holder h = new Holder(name);
        Inventory inv = Bukkit.createInventory(h, 54, DonutPlugin.color("&d&lShop &8- &f" + name));
        h.inv = inv;
        for (int i = 0; i < Math.min(45, c.items.size()); i++) {
            Item it = c.items.get(i);
            ItemStack is = new ItemStack(it.mat());
            ItemMeta m = is.getItemMeta();
            m.setLore(List.of(
                    DonutPlugin.color("&7Buy: &a$" + DataManager.fmt(it.buy())),
                    DonutPlugin.color("&7Sell: &e$" + DataManager.fmt(it.sell())),
                    "",
                    DonutPlugin.color("&eClick &7to buy 1"),
                    DonutPlugin.color("&eShift-click &7to buy a stack")));
            is.setItemMeta(m);
            inv.setItem(i, is);
        }
        ItemStack back = new ItemStack(Material.BARRIER);
        ItemMeta bm = back.getItemMeta();
        bm.setDisplayName(DonutPlugin.color("&cBack"));
        back.setItemMeta(bm);
        inv.setItem(49, back);
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getRawSlot();
        List<Cat> list = new ArrayList<>(cats.values());
        if (h.cat == null) {
            int idx = slot - 10;
            if (slot >= 10 && slot <= 16 && idx < list.size()) openCat(p, list.get(idx).name);
        } else {
            if (slot == 49) { openMain(p); return; }
            Cat c = cats.get(h.cat);
            if (c != null && slot >= 0 && slot < 45 && slot < c.items.size())
                buy(p, c.items.get(slot), e.isShiftClick() ? 64 : 1);
        }
    }

    private void buy(Player p, Item it, int amt) {
        amt = Math.min(amt, it.mat().getMaxStackSize());
        double cost = it.buy() * amt;
        DataManager.PD d = pl.data.get(p.getUniqueId());
        if (d.money < cost) { pl.msg(p, "&cYou need &f$" + DataManager.fmt(cost) + "&c."); return; }
        d.money -= cost;
        Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(it.mat(), amt));
        for (ItemStack l : left.values()) d.money += it.buy() * l.getAmount();
        pl.msg(p, "&aBought &f" + amt + "x " + pretty(it.mat()) + " &afor &f$" + DataManager.fmt(cost));
    }

    public void sellHand(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        Double price = sellPrices.get(hand.getType());
        if (hand.getType().isAir() || price == null) { pl.msg(p, "&cThat item can't be sold."); return; }
        double total = price * hand.getAmount();
        pl.data.get(p.getUniqueId()).money += total;
        p.getInventory().setItemInMainHand(null);
        pl.msg(p, "&aSold for &f$" + DataManager.fmt(total));
    }

    public void sellAll(Player p) {
        double total = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack is = p.getInventory().getItem(i);
            if (is == null) continue;
            Double price = sellPrices.get(is.getType());
            if (price == null) continue;
            total += price * is.getAmount();
            p.getInventory().setItem(i, null);
        }
        if (total <= 0) { pl.msg(p, "&cNothing sellable in your inventory."); return; }
        pl.data.get(p.getUniqueId()).money += total;
        pl.msg(p, "&aSold everything for &f$" + DataManager.fmt(total));
    }

    private static String pretty(Material m) { return m.name().toLowerCase().replace('_', ' '); }
}
