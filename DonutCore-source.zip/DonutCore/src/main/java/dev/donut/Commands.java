package dev.donut;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class Commands implements CommandExecutor {
    private final DonutPlugin pl;
    public Commands(DonutPlugin pl) { this.pl = pl; }

    public static Location getSpawn(DonutPlugin pl) {
        var c = pl.getConfig();
        if (!c.contains("spawn.world")) return null;
        World w = Bukkit.getWorld(c.getString("spawn.world"));
        if (w == null) return null;
        return new Location(w, c.getDouble("spawn.x"), c.getDouble("spawn.y"), c.getDouble("spawn.z"),
                (float) c.getDouble("spawn.yaw"), (float) c.getDouble("spawn.pitch"));
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        switch (cmd.getName().toLowerCase()) {
            case "balance" -> {
                Player t = (a.length > 0) ? Bukkit.getPlayerExact(a[0]) : (s instanceof Player p ? p : null);
                if (t == null) { pl.msg(s, "&cPlayer not found."); return true; }
                pl.msg(s, "&f" + t.getName() + "&7's balance: &a$" + DataManager.fmt(pl.data.get(t.getUniqueId()).money));
            }
            case "pay" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length < 2) { pl.msg(s, "&cUsage: /pay <player> <amount>"); return true; }
                Player t = Bukkit.getPlayerExact(a[0]);
                if (t == null || t.equals(p)) { pl.msg(s, "&cInvalid player."); return true; }
                double amt;
                try { amt = DataManager.parse(a[1]); } catch (NumberFormatException ex) { pl.msg(s, "&cInvalid amount."); return true; }
                var from = pl.data.get(p.getUniqueId());
                if (amt <= 0 || from.money < amt) { pl.msg(s, "&cYou don't have enough money."); return true; }
                from.money -= amt;
                pl.data.get(t.getUniqueId()).money += amt;
                pl.msg(p, "&7You paid &f" + t.getName() + " &a$" + DataManager.fmt(amt));
                pl.msg(t, "&f" + p.getName() + " &7paid you &a$" + DataManager.fmt(amt));
            }
            case "rtp" -> { if (s instanceof Player p) pl.rtp.start(p); }
            case "shop" -> { if (s instanceof Player p) pl.shop.openMain(p); }
            case "sell" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length > 0 && a[0].equalsIgnoreCase("all")) pl.shop.sellAll(p);
                else pl.shop.sellHand(p);
            }
            case "spawn" -> {
                if (!(s instanceof Player p)) return true;
                Location sp = getSpawn(pl);
                if (sp == null) { pl.msg(s, "&cSpawn isn't set."); return true; }
                p.teleportAsync(sp);
            }
            case "setspawn" -> {
                if (!(s instanceof Player p)) return true;
                Location l = p.getLocation();
                var c = pl.getConfig();
                c.set("spawn.world", l.getWorld().getName());
                c.set("spawn.x", l.getX()); c.set("spawn.y", l.getY()); c.set("spawn.z", l.getZ());
                c.set("spawn.yaw", l.getYaw()); c.set("spawn.pitch", l.getPitch());
                pl.saveConfig();
                pl.msg(s, "&aSpawn set.");
            }
            case "eco" -> {
                if (a.length < 3) { pl.msg(s, "&cUsage: /eco <give|take|set> <player> <amount>"); return true; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) { pl.msg(s, "&cPlayer not found."); return true; }
                double amt;
                try { amt = DataManager.parse(a[2]); } catch (NumberFormatException ex) { pl.msg(s, "&cInvalid amount."); return true; }
                var d = pl.data.get(t.getUniqueId());
                switch (a[0].toLowerCase()) {
                    case "give" -> d.money += amt;
                    case "take" -> d.money = Math.max(0, d.money - amt);
                    case "set" -> d.money = amt;
                    default -> { pl.msg(s, "&cUse give, take or set."); return true; }
                }
                pl.msg(s, "&aDone. &f" + t.getName() + " &7now has &a$" + DataManager.fmt(d.money));
            }
            case "donutreload" -> {
                pl.reloadConfig();
                pl.shop.load();
                for (Player p : Bukkit.getOnlinePlayers()) pl.boards.create(p);
                pl.msg(s, "&aReloaded.");
            }
        }
        return true;
    }
}
