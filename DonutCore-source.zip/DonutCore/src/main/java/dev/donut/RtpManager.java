package dev.donut;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class RtpManager {
    private final DonutPlugin pl;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> pending = new HashSet<>();
    private static final Set<Material> BAD = Set.of(Material.LAVA, Material.WATER, Material.CACTUS, Material.FIRE,
            Material.MAGMA_BLOCK, Material.SWEET_BERRY_BUSH, Material.POWDER_SNOW, Material.CAMPFIRE);

    public RtpManager(DonutPlugin pl) { this.pl = pl; }

    public void start(Player p) {
        if (pending.contains(p.getUniqueId())) { pl.msg(p, "&cYou are already teleporting!"); return; }
        long cd = pl.getConfig().getLong("rtp.cooldown", 30) * 1000;
        long left = cooldowns.getOrDefault(p.getUniqueId(), 0L) + cd - System.currentTimeMillis();
        if (left > 0 && !p.hasPermission("donut.admin")) {
            pl.msg(p, "&cWait &f" + (left / 1000 + 1) + "s &cbefore using /rtp again.");
            return;
        }
        pending.add(p.getUniqueId());
        final Location start = p.getLocation().clone();
        final int secs = pl.getConfig().getInt("rtp.countdown", 5);
        new BukkitRunnable() {
            int t = secs;
            @Override public void run() {
                if (!p.isOnline()) { pending.remove(p.getUniqueId()); cancel(); return; }
                Location now = p.getLocation();
                if (now.getBlockX() != start.getBlockX() || now.getBlockY() != start.getBlockY() || now.getBlockZ() != start.getBlockZ()) {
                    pl.msg(p, "&cTeleport cancelled, you moved!");
                    pending.remove(p.getUniqueId()); cancel(); return;
                }
                if (t <= 0) { cancel(); search(p, pl.getConfig().getInt("rtp.attempts", 15)); return; }
                p.sendActionBar(DonutPlugin.color("&dTeleporting in &f" + t + "s &7- don't move"));
                t--;
            }
        }.runTaskTimer(pl, 0L, 20L);
    }

    private void search(Player p, int attempts) {
        if (attempts <= 0) {
            pending.remove(p.getUniqueId());
            pl.msg(p, "&cCouldn't find a safe spot, try again.");
            return;
        }
        World w = Bukkit.getWorld(pl.getConfig().getString("world", "world"));
        if (w == null) w = p.getWorld();
        final World world = w;
        int min = pl.getConfig().getInt("rtp.min-radius", 500);
        int max = pl.getConfig().getInt("rtp.max-radius", 10000);
        Random r = new Random();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = min + r.nextDouble() * (max - min);
        int x = (int) (Math.cos(ang) * dist), z = (int) (Math.sin(ang) * dist);

        world.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk -> {
            if (!p.isOnline()) { pending.remove(p.getUniqueId()); return; }
            Block ground = world.getHighestBlockAt(x, z);
            Block above = ground.getRelative(0, 1, 0);
            if (BAD.contains(ground.getType()) || ground.isLiquid() || !above.isPassable() || ground.getY() <= world.getMinHeight() + 1) {
                search(p, attempts - 1);
                return;
            }
            Location dest = new Location(world, x + 0.5, ground.getY() + 1, z + 0.5);
            p.teleportAsync(dest).thenAccept(ok -> {
                pending.remove(p.getUniqueId());
                if (ok) {
                    cooldowns.put(p.getUniqueId(), System.currentTimeMillis());
                    pl.msg(p, "&aTeleported to &f" + x + ", " + (int) dest.getY() + ", " + z);
                }
            });
        });
    }
}
