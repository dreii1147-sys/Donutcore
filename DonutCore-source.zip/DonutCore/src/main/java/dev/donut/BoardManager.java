package dev.donut;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.List;

public class BoardManager {
    private final DonutPlugin pl;
    public BoardManager(DonutPlugin pl) { this.pl = pl; }

    public void create(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("donut", "dummy", DonutPlugin.color(pl.getConfig().getString("scoreboard.title", "DONUT")));
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        List<String> lines = pl.getConfig().getStringList("scoreboard.lines");
        int n = Math.min(lines.size(), 15);
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("l" + i);
            String entry = ChatColor.values()[i] + "" + ChatColor.RESET;
            t.addEntry(entry);
            o.getScore(entry).setScore(n - i);
        }
        p.setScoreboard(sb);
        update(p);
    }

    public void update(Player p) {
        Scoreboard sb = p.getScoreboard();
        if (sb.getObjective("donut") == null) { create(p); return; }
        DataManager.PD d = pl.data.get(p.getUniqueId());
        List<String> lines = pl.getConfig().getStringList("scoreboard.lines");
        int n = Math.min(lines.size(), 15);
        for (int i = 0; i < n; i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String l = lines.get(i)
                    .replace("%money%", DataManager.fmt(d.money))
                    .replace("%shards%", DataManager.fmt(d.shards))
                    .replace("%kills%", String.valueOf(d.kills))
                    .replace("%deaths%", String.valueOf(d.deaths))
                    .replace("%playtime%", DataManager.time(d.playtime))
                    .replace("%online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                    .replace("%player%", p.getName());
            t.setPrefix(DonutPlugin.color(l));
        }
    }

    public void remove(Player p) { p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard()); }
}
