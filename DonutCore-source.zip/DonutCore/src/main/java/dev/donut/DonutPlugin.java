package dev.donut;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class DonutPlugin extends JavaPlugin {
    public DataManager data;
    public ShopManager shop;
    public RtpManager rtp;
    public BoardManager boards;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        data = new DataManager(this);
        shop = new ShopManager(this);
        rtp = new RtpManager(this);
        boards = new BoardManager(this);

        Commands cmds = new Commands(this);
        for (String n : new String[]{"balance", "pay", "rtp", "shop", "sell", "spawn", "setspawn", "eco", "donutreload"}) {
            PluginCommand c = getCommand(n);
            if (c != null) { c.setExecutor(cmds); }
        }
        Bukkit.getPluginManager().registerEvents(new Events(this), this);
        Bukkit.getPluginManager().registerEvents(shop, this);

        // scoreboard + playtime tick every second
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                data.get(p.getUniqueId()).playtime++;
                boards.update(p);
            }
        }, 20L, 20L);
        // autosave every 5 minutes
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> data.save(), 6000L, 6000L);
        for (Player p : Bukkit.getOnlinePlayers()) boards.create(p);
    }

    @Override
    public void onDisable() { if (data != null) data.save(); }

    public String prefix() { return color(getConfig().getString("messages.prefix", "&d&lDonut &8» &7")); }
    public void msg(org.bukkit.command.CommandSender s, String m) { s.sendMessage(prefix() + color(m)); }
    public static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
}
