package dev.donut;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DataManager {
    public static class PD { public double money; public int shards, kills, deaths; public long playtime; }

    private final DonutPlugin pl;
    private final Map<UUID, PD> map = new ConcurrentHashMap<>();
    private final File file;
    private final YamlConfiguration yml;

    public DataManager(DonutPlugin pl) {
        this.pl = pl;
        pl.getDataFolder().mkdirs();
        file = new File(pl.getDataFolder(), "data.yml");
        yml = YamlConfiguration.loadConfiguration(file);
    }

    public PD get(UUID id) {
        return map.computeIfAbsent(id, k -> {
            PD d = new PD();
            String p = "players." + k + ".";
            if (yml.contains("players." + k)) {
                d.money = yml.getDouble(p + "money");
                d.shards = yml.getInt(p + "shards");
                d.kills = yml.getInt(p + "kills");
                d.deaths = yml.getInt(p + "deaths");
                d.playtime = yml.getLong(p + "playtime");
            } else d.money = pl.getConfig().getDouble("start-money", 1000);
            return d;
        });
    }

    public synchronized void save() {
        for (Map.Entry<UUID, PD> e : map.entrySet()) {
            String p = "players." + e.getKey() + ".";
            PD d = e.getValue();
            yml.set(p + "money", d.money);
            yml.set(p + "shards", d.shards);
            yml.set(p + "kills", d.kills);
            yml.set(p + "deaths", d.deaths);
            yml.set(p + "playtime", d.playtime);
        }
        try { yml.save(file); } catch (IOException ex) { pl.getLogger().warning("Could not save data: " + ex.getMessage()); }
    }

    /** 1500 -> 1.5K, 2000000 -> 2M */
    public static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) { v /= 1000; i++; }
        String s = (v == Math.floor(v)) ? String.valueOf((long) v) : String.format("%.2f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
        return s + suf[i];
    }

    /** parses 10, 1.5k, 2m, 3b */
    public static double parse(String s) {
        s = s.toLowerCase().trim();
        double mult = 1;
        if (s.endsWith("k")) { mult = 1e3; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("m")) { mult = 1e6; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("b")) { mult = 1e9; s = s.substring(0, s.length() - 1); }
        return Double.parseDouble(s) * mult;
    }

    public static String time(long sec) {
        long d = sec / 86400, h = (sec % 86400) / 3600, m = (sec % 3600) / 60;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }
}
